from flask import Flask, request, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_bootstrap import Bootstrap

app = Flask(__name__)
bootstrap = Bootstrap(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mssql+pyodbc://sa:Mac_Universe2022@185.130.82.55,' \
                                        '3389/students?driver=ODBC+Driver+17+for+SQL+Server&charset=utf8mb4'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fullname = db.Column(db.String(80, collation='Latin1_General_CI_AS'), nullable=False)
    faculty = db.Column(db.String(80, collation='Latin1_General_CI_AS'), nullable=False)
    groupnumber = db.Column(db.String(10, collation='Latin1_General_CI_AS'), nullable=False)
    category = db.Column(db.String(10, collation='Latin1_General_CI_AS'), nullable=False)
    category_other = db.Column(db.String(10, collation='Latin1_General_CI_AS'), nullable=False)
    topic = db.Column(db.String(collation='Latin1_General_CI_AS'), nullable=False)
    problem = db.Column(db.String(collation='Latin1_General_CI_AS'), nullable=False)


@app.route('/', methods=['GET', 'POST'])
def form():
    if request.method == 'POST':
        fullname = request.form.get('fullname')
        faculty = request.form.get('faculty')
        groupnumber = request.form.get('groupnumber')
        category = request.form.get('category')
        category_other = request.form.get('category_other')
        topic = request.form.get('topic')
        problem = request.form.get('problem')

        data = Feedback(
            fullname=fullname,
            faculty=faculty,
            groupnumber=groupnumber,
            category = category,
            category_other = category_other,
            topic=topic,
            problem=problem
        )
        db.create_all()

        db.session.add(data)
        db.session.commit()

        print(f"Received data: {request.form.get('fullname')}")

        return f'Data received: {data.fullname}'

    return render_template('index.html', bootstrap=bootstrap)


@app.route('/database')
def database():
    feedbacks = Feedback.query.all()
    return render_template('database.html', feedbacks=feedbacks)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
